package com.company.ems.dao;

import java.util.List;

import com.company.ems.model.EducationalDetails;
import com.company.ems.model.EmergencyContact;
import com.company.ems.model.EmpBankDtls;
import com.company.ems.model.EmpInfo;
import com.company.ems.model.FamilyInformation;
import com.company.ems.model.WorkExperience;

public interface EmployeeDao {

	public String saveEmpData(EmpInfo empinfo);

	public int saveEmpBankData(EmpBankDtls empbankdtls);

	public int saveEmergencyContactData(EmergencyContact emergencycontact);

	public int saveEducationalDetailsData(EducationalDetails educationaldetails);

	public int saveFamilyInformationData(FamilyInformation familyinformation);

	public int saveWorkExperienceData(WorkExperience workexp);

	public List<EmpInfo> getEmployeeDetailsByEMSEmpCode(String uname);

	public List<EducationalDetails> getEducationalDetailsByEMSID(String emsid);

	public List<WorkExperience> getworkExperienceByEMSID(String emsid);

	public List<EmpBankDtls> getBankDetailsByEMSID(String emsid);

	public List<EmergencyContact> getEmergencyContactDetailsByEMSID(String emsid);

	public List<FamilyInformation> getFamilyInformationByEMSID(String emsempcode);

	public EducationalDetails getSingleEducationalDetailsByEMSID(
			String emsempcode,String id);

	public WorkExperience getSingeWorkExperienceByEMSID(String emsempcode,String id);
}
