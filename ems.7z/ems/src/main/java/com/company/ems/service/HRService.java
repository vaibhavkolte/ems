package com.company.ems.service;

import java.util.List;

import com.company.ems.model.EmpInfo;
import com.company.ems.model.LoginDetails;

public interface HRService {

	int doRegistration(LoginDetails loginDetails);

	public List<EmpInfo> getAllEmployeeDetails(String type);

	public List<LoginDetails> getActiveEmplyee();
	
	public List<LoginDetails> getInactiveEmplyee();

	public int deactivateEmployee(LoginDetails loginDetails);

	public LoginDetails getEmpDetails(String emsempcode);

	List<EmpInfo> getBirthDayDetails(java.sql.Date fromdate,
			java.sql.Date todate);

	public List<LoginDetails> getAllEmpLoginDetails();

}
