package com.company.ems.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

@Entity
@Table(name="ToDoList")
public class ToDoList {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	@Valid 
	@NotBlank(message="Task mandatory")
	@Column(name="task")
	private String task;
	@Valid 
	@NotBlank(message="Time format mandatory")
	@Column(name="timeformat")
	private String timeformat;
	@Valid 
	@NotBlank(message="Time mandatory")
	@NumberFormat(style=Style.NUMBER)
	@Column(name="time")
	private String time;
	@Column(name="isCompleted")
	private String isCompleted;
	@Column(name="emsempcode")
	private String emsempcode;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getTimeformat() {
		return timeformat;
	}
	public void setTimeformat(String timeformat) {
		this.timeformat = timeformat;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public String getIsCompleted() {
		return isCompleted;
	}
	public void setIsCompleted(String isCompleted) {
		this.isCompleted = isCompleted;
	}

}
