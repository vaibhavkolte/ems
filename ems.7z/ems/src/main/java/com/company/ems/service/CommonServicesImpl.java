package com.company.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.ems.dao.CommonDao;
import com.company.ems.model.ToDoList;

@Service("CommonServices")
public class CommonServicesImpl implements CommonServices{

	@Autowired
	private CommonDao commonDao;
	
	@Override
	public int createTask(ToDoList todoList) {
		return commonDao.createTask(todoList);
	}

	@Override
	public List<ToDoList> getAllTaskDetails(String emsempcode,
			String isCompleted,int id) {
		// TODO Auto-generated method stub
		return commonDao.getAllTaskDetails(emsempcode,isCompleted,id);
	}

}
