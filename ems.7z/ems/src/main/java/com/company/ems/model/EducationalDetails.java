package com.company.ems.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="EducationalDetails")
public class EducationalDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	@Column(name="emsempcode")
	private String emsempcode;
	@Valid 
	@NotBlank(message="Educational Level mandatory")
	@Column(name="educationallevel")
	private String educationallevel;
	@Valid 
	@NotBlank(message="Board/University mandatory")
	@Column(name="board_university_name")
	private  String board_university_name;
	@Valid 
	@NotBlank(message="School/College Name mandatory")
	@Column(name="school_college_name")
	private  String school_college_name;
	@Valid 
	@NotBlank(message="Year Of Passing mandatory")
	@Column(name="year_of_passing")
	private String year_of_passing;
	@Valid 
	@NotBlank(message="Marks mandatory")
	@Column(name="marks")
	private String marks;
	@Column(name="filepath")
	private String filepath;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public String getEducationallevel() {
		return educationallevel;
	}
	public void setEducationallevel(String educationallevel) {
		this.educationallevel = educationallevel;
	}
	public String getBoard_university_name() {
		return board_university_name;
	}
	public void setBoard_university_name(String board_university_name) {
		this.board_university_name = board_university_name;
	}
	public String getSchool_college_name() {
		return school_college_name;
	}
	public void setSchool_college_name(String school_college_name) {
		this.school_college_name = school_college_name;
	}
	public String getYear_of_passing() {
		return year_of_passing;
	}
	public void setYear_of_passing(String year_of_passing) {
		this.year_of_passing = year_of_passing;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	
}
