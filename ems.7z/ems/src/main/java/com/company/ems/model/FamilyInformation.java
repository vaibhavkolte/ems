package com.company.ems.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="FamilyInformation")
public class FamilyInformation {
	
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		@Column(name="id")
		private int id;
		@Column(name="emsempcode")
		private String emsempcode;
		@Valid 
		@NotBlank(message="Father Name mandatory")
		@Column(name="fathername")
		private String fathername;
		@Column(name="fdob")
		private Date fdob;
		@Valid 
		@NotBlank(message="Mother Name mandatory")
		@Column(name="mothername")
		private String mothername;
		@Column(name="mdob")
		private Date mdob;
		@Column(name="hwname")
		private String hwname;
		@Column(name="hwdob")
		private Date hwdob;
		@Column(name="childnameone")
		private String childnameone;
		@Column(name="conedob")
		private Date conedob;
		@Column(name="ctwoname")
		private String ctwoname;
		@Column(name="ctwodob")
		private Date ctwodob;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getEmsempcode() {
			return emsempcode;
		}
		public void setEmsempcode(String emsemocode) {
			this.emsempcode = emsemocode;
		}
		public String getFathername() {
			return fathername;
		}
		public void setFathername(String fathername) {
			this.fathername = fathername;
		}
		public Date getFdob() {
			return fdob;
		}
		public void setFdob(Date fdob) {
			this.fdob = fdob;
		}
		public String getMothername() {
			return mothername;
		}
		public void setMothername(String mothername) {
			this.mothername = mothername;
		}
		public Date getMdob() {
			return mdob;
		}
		public void setMdob(Date mdob) {
			this.mdob = mdob;
		}
		public String getHwname() {
			return hwname;
		}
		public void setHwname(String hwname) {
			this.hwname = hwname;
		}
		public Date getHwdob() {
			return hwdob;
		}
		public void setHwdob(Date hwdob) {
			this.hwdob = hwdob;
		}
		public String getChildnameone() {
			return childnameone;
		}
		public void setChildnameone(String childnameone) {
			this.childnameone = childnameone;
		}
		public Date getConedob() {
			return conedob;
		}
		public void setConedob(Date conedob) {
			this.conedob = conedob;
		}
		public String getCtwoname() {
			return ctwoname;
		}
		public void setCtwoname(String ctwoname) {
			this.ctwoname = ctwoname;
		}
		public Date getCtwodob() {
			return ctwodob;
		}
		public void setCtwodob(Date ctwodob) {
			this.ctwodob = ctwodob;
		}
		@Override
		public String toString() {
			return "FamilyInformation [id=" + id + ", emsempcode=" + emsempcode
					+ ", fathername=" + fathername + ", fdob=" + fdob
					+ ", mothername=" + mothername + ", mdob=" + mdob
					+ ", hwname=" + hwname + ", hwdob=" + hwdob
					+ ", childnameone=" + childnameone + ", conedob=" + conedob
					+ ", ctwoname=" + ctwoname + ", ctwodob=" + ctwodob + "]";
		}
		
	
}

