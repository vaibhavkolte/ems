package com.company.ems;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.ws.rs.PathParam;
import javax.xml.ws.BindingType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.company.ems.model.EducationalDetails;
import com.company.ems.model.EmergencyContact;
import com.company.ems.model.EmpBankDtls;
import com.company.ems.model.EmpInfo;
import com.company.ems.model.FamilyInformation;
import com.company.ems.model.LoginDetails;
import com.company.ems.model.WorkExperience;
import com.company.ems.service.EmployeeService;
import com.company.ems.service.HRService;

@Controller
public class HRController extends SecurityController{

	@Autowired
	private HRService hrService;
	@Autowired
	private EmployeeService employeeService;

	@RequestMapping(value = "/hrhome", method = RequestMethod.GET)
	public String profile(Locale locale, Model model, HttpSession session,
			HttpServletRequest request) {
		if (!isLoggedIn(session)) {
			return "redirect:/";
		}

		if (!session.getAttribute("role").equals("HR"))
			return "redirect:/AccessDenied";

		try {
			
			List<LoginDetails> activeemp = hrService.getActiveEmplyee();
			List<LoginDetails> inactiveemp = hrService.getInactiveEmplyee();

			Calendar calendar = Calendar.getInstance();
			java.sql.Date today=new java.sql.Date(calendar.getTimeInMillis());  
			calendar.add(Calendar.DATE, 30);
			java.sql.Date date=new java.sql.Date(calendar.getTimeInMillis());

			List<EmpInfo> empinfo = hrService.getBirthDayDetails(today,
					date);
			
			int active = activeemp.size();
			int inactive = inactiveemp.size();
			int total = active + inactive;
			model.addAttribute("active", active);
			model.addAttribute("inactive", inactive);
			model.addAttribute("total", total);
			model.addAttribute("dobinfo", empinfo);
		} catch (Exception e) {
			System.out.println(e);
			System.out.println(e);
		}

		return "Hr/Home_hr";
	}

	@RequestMapping(value = "/employeedetails/{type}", method = RequestMethod.GET)
	public String EmployeeDetails(Locale locale, Model model,
			@PathVariable(value = "type") String type,HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";
			
			type = type.equalsIgnoreCase("active")?"A":"I";

			List<EmpInfo> empinfo = hrService.getAllEmployeeDetails(type);
			model.addAttribute("employeedetails", empinfo);
			model.addAttribute("type", type);
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return "Hr/EmployeeDetails";
	}

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String registration(Locale locale, Model model, HttpSession session,
			HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";

			model.addAttribute("login", new LoginDetails());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Hr/RegisterEmployee";
	}

	@RequestMapping(value = "/registerEmployee", method = RequestMethod.POST)
	public String doRegistration(Locale locale, Model model,
			@ModelAttribute("login") @Valid LoginDetails loginDetails,BindingResult bindingResult,
			HttpSession session, HttpServletRequest request) {
		try {
			
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if(bindingResult.hasErrors()){
				return "Hr/RegisterEmployee";
	        }
			
			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";

			try {
				
				LoginDetails chkexist = hrService.getEmpDetails(loginDetails.getUsername());
				if(chkexist!=null)
				{
					model.addAttribute("login", new LoginDetails());
					model.addAttribute("error", "Username "+loginDetails.getUsername()+" is not available.");
					return "Hr/RegisterEmployee";
				}
				
				loginDetails.setEmsempcode(generateId());
				loginDetails.setIsactive("Y");
				@SuppressWarnings("unused")
				int rowcnt = hrService.doRegistration(loginDetails);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/registration";
	}

	@RequestMapping(value = "/view/{emsempid}", method = RequestMethod.GET)
	public String viewDetails(
			@PathVariable(value = "emsempid") String emsempcode, Locale locale,
			Model model, HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";

			List<EmpInfo> empinfo = employeeService
					.getEmployeeDetailsByEMSEmpCode(emsempcode);
			model.addAttribute("empinfolist", empinfo);

			List<EmpBankDtls> bankinfo = employeeService
					.getBankDetailsByEMSID(emsempcode);
			model.addAttribute("bankinfo", bankinfo);

			List<EducationalDetails> educationaldetailslist = employeeService
					.getEducationalDetailsByEMSID(emsempcode);
			model.addAttribute("educationaldetailslist", educationaldetailslist);

			List<EmergencyContact> emergencycnt = employeeService
					.getEmergencyContactDetailsByEMSID(emsempcode);
			model.addAttribute("emergencycnt", emergencycnt);

			List<WorkExperience> workexplist = employeeService
					.getworkExperienceByEMSID(emsempcode);
			model.addAttribute("workexplist", workexplist);

			List<FamilyInformation> familyinfo = employeeService
					.getFamilyInformationByEMSID(emsempcode);
			model.addAttribute("familyinfo", familyinfo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "Hr/ViewDetails";
	}

	@RequestMapping(value = {"/Inactive/{emsempid}","/Activate/{emsempid}","/disable-login/{emsempid}","/enable-login/{emsempid}"}, method = RequestMethod.GET)
	public String deactivateEmployee(Locale locale, Model model,
			@PathVariable(value = "emsempid") String emsempcode,
			HttpSession session, HttpServletRequest request) {
		String redirectmethod = "";
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";

			String req = request.getRequestURI();
			
			LoginDetails loginDetails = hrService.getEmpDetails(emsempcode);
			List<EmpInfo> empinfo1 = employeeService
					.getEmployeeDetailsByEMSEmpCode(emsempcode);
			EmpInfo empinfo = null;
			if(empinfo1.size()>0)
			empinfo = empinfo1.get(0);
			if(req.contains("/Inactive"))
			{
				loginDetails.setIsactive("N");
				empinfo.setIsactive("I");
				redirectmethod = "employeedetails/inactive";
				@SuppressWarnings("unused")
				int rowcnt1 = hrService.deactivateEmployee(loginDetails);
				String rowcnt2 = employeeService.saveEmpData(empinfo);
			}
			else if(req.contains("/Activate"))
			{
				loginDetails.setIsactive("Y");
				empinfo.setIsactive("A");
				redirectmethod = "employeedetails/active";
				@SuppressWarnings("unused")
				int rowcnt1 = hrService.deactivateEmployee(loginDetails);
				String rowcnt2 = employeeService.saveEmpData(empinfo);
			}
			else if(req.contains("/disable-login"))
			{
				loginDetails.setIsactive("N");
				if(empinfo1.size()>0)
				empinfo.setIsactive("I");
				redirectmethod = "reset-password";
				@SuppressWarnings("unused")
				int rowcnt1 = hrService.deactivateEmployee(loginDetails);
				if(empinfo1.size()>0)
				 employeeService.saveEmpData(empinfo);
			}
			else if(req.contains("/enable-login"))
			{
				loginDetails.setIsactive("Y");
				if(empinfo1.size()>0)
				empinfo.setIsactive("A");
				redirectmethod = "reset-password";
				@SuppressWarnings("unused")
				int rowcnt1 = hrService.deactivateEmployee(loginDetails);
				if(empinfo1.size()>0)
				 employeeService.saveEmpData(empinfo);
			}
			//loginDetails.setIsactive(loginDetails.getIsactive().equalsIgnoreCase("Y")?"N":"Y");
			//empinfo.setIsactive(empinfo.getIsactive().equalsIgnoreCase("A")?"I":"A");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/"+redirectmethod;
	}

	private String generateId() {
		DateFormat dateFormat = new SimpleDateFormat("yyMMdd");
		Date date = new Date();
		String getDate = dateFormat.format(date);

		String numbers = "0123456789";

		Random rndm_method = new Random();

		char[] uid = new char[4];

		for (int i = 0; i < 4; i++) {
			uid[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
		}
		String id = String.valueOf(uid);
		String emsid = "EMS" + getDate + id;
		// System.out.println("EMS"+getDate + id);
		return emsid;
	}

	@RequestMapping(value = "/editDetails", method = RequestMethod.POST)
	public String markAsEditable(Locale locale, Model model,
			HttpSession session, HttpServletRequest request) {
		try {

			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			String emsempcode = request.getParameter("emsempcode");
			String step = request.getParameter("step");
			String id = request.getParameter("id");

			if (step.equalsIgnoreCase("1")) {
				List<EmpInfo> empinfo1 = employeeService
						.getEmployeeDetailsByEMSEmpCode(emsempcode);
				EmpInfo empinfo = empinfo1.get(0);
				model.addAttribute("enable", false);
				model.addAttribute("update", "yes");
				model.addAttribute("empinfo", empinfo);
				return "Employee/employeehome";
			} else if (step.equalsIgnoreCase("2")) {
				List<EmpBankDtls> bankinfo1 = employeeService
						.getBankDetailsByEMSID(emsempcode);
				EmpBankDtls bankinfo = bankinfo1.get(0);
				model.addAttribute("enable", false);
				model.addAttribute("update", "yes");
				model.addAttribute("empbankdtls", bankinfo);
				return "Employee/EmpBankDtls";
			} else if (step.equalsIgnoreCase("3")) {
				List<EmergencyContact> emergencycnt1 = employeeService
						.getEmergencyContactDetailsByEMSID(emsempcode);
				EmergencyContact emergencycnt = emergencycnt1.get(0);
				model.addAttribute("enable", false);
				model.addAttribute("update", "yes");
				model.addAttribute("emergencycontact", emergencycnt);
				return "Employee/EmergencyContact";
			} else if (step.equalsIgnoreCase("4")) {
				List<FamilyInformation> familyinfo1 = employeeService
						.getFamilyInformationByEMSID(emsempcode);
				FamilyInformation familyinfo = familyinfo1.get(0);
				model.addAttribute("enable", false);
				model.addAttribute("update", "yes");
				model.addAttribute("familyinformation", familyinfo);
				return "Employee/FamilyInformation";
			} else if (step.equalsIgnoreCase("5")) {
				EducationalDetails educationaldetailslist = employeeService
						.getSingleEducationalDetailsByEMSID(emsempcode, id);
				model.addAttribute("enable", false);
				model.addAttribute("update", "yes");
				model.addAttribute("educationaldetails", educationaldetailslist);
				return "Employee/EducationalDetails";
			} else if (step.equalsIgnoreCase("6")) {
				WorkExperience workexplist = employeeService
						.getSingeWorkExperienceByEMSID(emsempcode, id);
				model.addAttribute("enable", false);
				model.addAttribute("update", "yes");
				model.addAttribute("workexp", workexplist);
				return "Employee/WorkExperience";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/employeedetails";
	}
	
	@RequestMapping(value = {"/reset-password"}, method = RequestMethod.GET)
	public String resetPasswordGet(Locale locale, Model model, HttpSession session,
			HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";
			
			List<LoginDetails> logindtls = hrService.getAllEmpLoginDetails();
			model.addAttribute("logindtls", logindtls);
			model.addAttribute("resetpassword", new LoginDetails());
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Hr/ResetPassword";
	}
	
	@RequestMapping(value = {"/resetpassword"}, method = RequestMethod.POST)
	public String resetPasswordPost(Locale locale, Model model,
			@ModelAttribute("resetpassword") LoginDetails loginDetails,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}

			if (!session.getAttribute("role").equals("HR"))
				return "redirect:/AccessDenied";
			
			LoginDetails logindtls = hrService.getEmpDetails(loginDetails.getEmsempcode());
			if(logindtls.getId() != 0)
			{
				logindtls.setPassword(loginDetails.getPassword());
				hrService.doRegistration(logindtls);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/reset-password";
	}

}
