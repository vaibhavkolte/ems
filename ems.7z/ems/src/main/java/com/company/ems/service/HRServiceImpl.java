package com.company.ems.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.ems.dao.HRServiceDao;
import com.company.ems.model.EmpInfo;
import com.company.ems.model.LoginDetails;

@Service("HRService")
public class HRServiceImpl implements HRService{

	@Autowired
	private HRServiceDao hrServiceDao;
	
	@Override
	public int doRegistration(LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		return hrServiceDao.doRegistration(loginDetails);
	}

	@Override
	public List<EmpInfo> getAllEmployeeDetails(String type) {
		// TODO Auto-generated method stub
		return hrServiceDao.getAllEmployeeDetails(type);
	}

	@Override
	public List<LoginDetails> getActiveEmplyee() {
		// TODO Auto-generated method stub
		return hrServiceDao.getActiveEmplyee();
	}

	@Override
	public List<LoginDetails> getInactiveEmplyee() {
		// TODO Auto-generated method stub
		return hrServiceDao.getInactiveEmplyee();
	}

	@Override
	public int deactivateEmployee(LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		return hrServiceDao.deactivateEmployee(loginDetails);
	}

	@Override
	public LoginDetails getEmpDetails(String emsempcode) {
		// TODO Auto-generated method stub
		return hrServiceDao.getEmpDetails(emsempcode);
	}

	@Override
	public List<EmpInfo> getBirthDayDetails(Date fromdate, Date todate) {
		// TODO Auto-generated method stub
		return hrServiceDao.getBirthDayDetails(fromdate,todate);
	}

	@Override
	public List<LoginDetails> getAllEmpLoginDetails() {
		// TODO Auto-generated method stub
		return hrServiceDao.getAllEmpLoginDetails();
	}

	
}
