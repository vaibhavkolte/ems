package com.company.ems.dao;

import java.sql.Date;
import java.util.List;

import com.company.ems.model.EmpInfo;
import com.company.ems.model.LoginDetails;

public interface HRServiceDao {

	public int doRegistration(LoginDetails loginDetails);

	public List<EmpInfo> getAllEmployeeDetails(String type);

	public List<LoginDetails> getActiveEmplyee();
	
	public List<LoginDetails> getInactiveEmplyee();

	public int deactivateEmployee(LoginDetails loginDetails);

	public LoginDetails getEmpDetails(String emsempcode);

	public List<EmpInfo> getBirthDayDetails(Date fromdate, Date todate);

	public List<LoginDetails> getAllEmpLoginDetails();

}
