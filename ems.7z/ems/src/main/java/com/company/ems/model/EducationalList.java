package com.company.ems.model;

import java.util.List;

public class EducationalList {
	
	private List<EducationalDetails> educationalDetails;

	public List<EducationalDetails> getEducationalDetails() {
		return educationalDetails;
	}
	
	public void setEducationalDetails(List<EducationalDetails> educationalDetails) {
		this.educationalDetails = educationalDetails;
	}

}
