package com.company.ems.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="WorkExperience")
public class WorkExperience {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	@Valid 
	@NotBlank(message="Organization Name mandatory")
	@Column(name="org_name")
	private String org_name;
	@Valid 
	@NotBlank(message="Designation mandatory")
	@Column(name="designation")
	private String designation;
	@Column(name="from_date")
	private  Date from;
	@Column(name="to_date")
	private  Date to;
	@Valid 
	@NotBlank(message="Reason For Leaving mandatory")
	@Column(name="reason_for_leaving")
	private String reason_for_leaving;
	@Column(name="emsempcode")
	private String emsempcode;
	@Column(name="filepath")
	private String filepath;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrg_name() {
		return org_name;
	}
	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Date getFrom() {
		return from;
	}
	public void setFrom(Date from) {
		this.from = from;
	}
	public Date getTo() {
		return to;
	}
	public void setTo(Date to) {
		this.to = to;
	}
	public String getReason_for_leaving() {
		return reason_for_leaving;
	}
	public void setReason_for_leaving(String reason_for_leaving) {
		this.reason_for_leaving = reason_for_leaving;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
}
