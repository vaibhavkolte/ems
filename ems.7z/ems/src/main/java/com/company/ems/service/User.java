package com.company.ems.service;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

public class User implements HttpSessionBindingListener {

    private String name;

    public User(String name) {
        this.name = name;
    }
    public User() {
    }

    @Override
    public void valueBound(HttpSessionBindingEvent event) {
        User user = (User)event.getValue();
        System.out.println("New user bound in session with name: " + user.getName());
    }

    @Override
    public void valueUnbound(HttpSessionBindingEvent event) {
        User user = (User)event.getValue();
        System.out.println("User with name: " + user.getName() + " removed from session");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}