package com.company.ems.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.company.ems.model.LoginDetails;


@Transactional
@Repository("LoginDao")
public class LoginDaoImpl implements LoginDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	public String findUserByUserName(String UserName) {
		// TODO Auto-generated method stub
		try{
		ArrayList UserNameList = new ArrayList();

		UserNameList = (ArrayList<LoginDetails>) sessionFactory.getCurrentSession()
				.createCriteria(LoginDetails.class)
				.add(Restrictions.eq("username", UserName))
				.setProjection(Projections.property("username")).list();

		if (UserNameList.isEmpty()) {
			System.out.println("inside null");
			return null;
		} else
			return (String) UserNameList.get(0);
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public String findPassByUserName(String UserName) {
		// TODO Auto-generated method stub
		try{
		ArrayList PasswordList = new ArrayList();

		PasswordList = (ArrayList<LoginDetails>) sessionFactory.getCurrentSession()
				.createCriteria(LoginDetails.class)
				.add(Restrictions.eq("username", UserName))
				.setProjection(Projections.property("password")).list();

		if (PasswordList.isEmpty()) {
			System.out.println("inside null");
			return null;
		} else
			return (String) PasswordList.get(0);
	}catch(Exception e)
	{
		e.printStackTrace();
		return null;
	}

	}

	@Override
	public String getRoleByUserName(String uname) {
		List role = new ArrayList();
		
		 role = sessionFactory.getCurrentSession()
		.createCriteria(LoginDetails.class)
		.add(Restrictions.eq("username", uname))
		.setProjection(Projections.property("role")).list();
		
		return (String) role.get(0);
	}

	@Override
	public String getEmsEmpByUserName(String uname) {
		// TODO Auto-generated method stub
		List emsempcode = new ArrayList();
		
		emsempcode = sessionFactory.getCurrentSession()
		.createCriteria(LoginDetails.class)
		.add(Restrictions.eq("username", uname))
		.setProjection(Projections.property("emsempcode")).list();
		
		return (String) emsempcode.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public LoginDetails getUserDetailsByUsername(String username) {
		// TODO Auto-generated method stub
		List<LoginDetails> loginDetails = new ArrayList<LoginDetails>();
		
		loginDetails = sessionFactory.getCurrentSession()
		.createCriteria(LoginDetails.class)
		.add(Restrictions.eq("username", username)).list();
		
		if(loginDetails.size()>0)
		return loginDetails.get(0);
		else 
		return null;
	}

}
