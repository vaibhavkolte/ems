package com.company.ems.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.company.ems.model.EducationalDetails;
import com.company.ems.model.EmergencyContact;
import com.company.ems.model.EmpBankDtls;
import com.company.ems.model.EmpInfo;
import com.company.ems.model.FamilyInformation;
import com.company.ems.model.WorkExperience;

@Repository("EmployeeDao")
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public String saveEmpData(EmpInfo empinfo) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(empinfo);
		return null;
	}

	@Override
	public int saveEmpBankData(EmpBankDtls empbankdtls) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(empbankdtls);
		return empbankdtls.getId();
	}

	@Override
	public int saveEmergencyContactData(EmergencyContact emergencycontact) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(emergencycontact);
		return emergencycontact.getId().intValue();
	}

	@Override
	public int saveEducationalDetailsData(EducationalDetails educationaldetails) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(educationaldetails);
		return 0;
	}

	@Override
	public int saveFamilyInformationData(FamilyInformation familyinformation) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(familyinformation);
		return familyinformation.getId();
	}

	@Override
	public int saveWorkExperienceData(WorkExperience workexp) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(workexp);
		return workexp.getId();
	}

	@Override
	public List<EmpInfo> getEmployeeDetailsByEMSEmpCode(String emsid) {

		@SuppressWarnings("unchecked")
		List<EmpInfo> empInfo = sessionFactory.getCurrentSession()
				.createCriteria(EmpInfo.class)
				.add(Restrictions.eq("emsempcode", emsid)).list();

		return empInfo;
	}

	@Override
	public List<EducationalDetails> getEducationalDetailsByEMSID(String emsid) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<EducationalDetails> worlorderlist = sessionFactory
				.getCurrentSession().createCriteria(EducationalDetails.class)
				.add(Restrictions.eq("emsempcode", emsid)).list();

		return worlorderlist;
	}

	@Override
	public List<WorkExperience> getworkExperienceByEMSID(String emsid) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<WorkExperience> workexplist = sessionFactory.getCurrentSession()
				.createCriteria(WorkExperience.class)
				.add(Restrictions.eq("emsempcode", emsid)).list();

		return workexplist;
	}

	@Override
	public List<EmpBankDtls> getBankDetailsByEMSID(String emsid) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<EmpBankDtls> bankdetls = sessionFactory.getCurrentSession()
				.createCriteria(EmpBankDtls.class)
				.add(Restrictions.eq("emsempcode", emsid)).list();

		return bankdetls;
	}

	@Override
	public List<EmergencyContact> getEmergencyContactDetailsByEMSID(String emsid) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<EmergencyContact> emerdtls = sessionFactory.getCurrentSession()
				.createCriteria(EmergencyContact.class)
				.add(Restrictions.eq("emsempcode", emsid)).list();

		return emerdtls;
	}

	@Override
	public List<FamilyInformation> getFamilyInformationByEMSID(String emsempcode) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<FamilyInformation> familyinfo = sessionFactory.getCurrentSession()
				.createCriteria(FamilyInformation.class)
				.add(Restrictions.eq("emsempcode", emsempcode)).list();

		return familyinfo;
	}

	@Override
	public EducationalDetails getSingleEducationalDetailsByEMSID(
			String emsempcode,String id) {
		int rowid  = Integer.parseInt(id);
		@SuppressWarnings("unchecked")
		List<EducationalDetails> edulist = sessionFactory.getCurrentSession()
				.createCriteria(EducationalDetails.class)
				.add(Restrictions.eq("emsempcode", emsempcode))
				.add(Restrictions.eq("id", rowid))
				.list();

		return edulist.get(0);
	}

	@Override
	public WorkExperience getSingeWorkExperienceByEMSID(String emsempcode,String id) {
		// TODO Auto-generated method stub
		int rowid  = Integer.parseInt(id);
		@SuppressWarnings("unchecked")
		List<WorkExperience> wrklist = sessionFactory.getCurrentSession()
				.createCriteria(WorkExperience.class)
				.add(Restrictions.eq("emsempcode", emsempcode))
				.add(Restrictions.eq("id", rowid))
				.list();

		return wrklist.get(0);
	}

}
