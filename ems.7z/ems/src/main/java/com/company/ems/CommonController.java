package com.company.ems;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@PropertySource("classpath:application.properties")
public class CommonController extends SecurityController {

	@Autowired
	private ServletContext context;
	
	@Autowired
	private Environment env;
	
	@RequestMapping(value = "/download-document/{emsempcode}/{NameOfFile}/{type}", method  = RequestMethod.GET)
	public String dowunloadsampleexcel( @PathVariable("NameOfFile") String NameOfFile,@PathVariable("type") String type,
			 @PathVariable("emsempcode") String emsempcode,HttpSession session,HttpServletRequest request, 
            HttpServletResponse response,Model model) {
		
		 try {
			 if (!isLoggedIn(session)) {
					return "redirect:/";
				}
			 
			 String filepath = env.getRequiredProperty("employeedocpath");
				filepath = filepath + emsempcode;
			 
			File file = new File(filepath+"/"+NameOfFile);
			 System.out.println("NameOfFile  is " + NameOfFile);
			 
			 System.out.println("file path = "+file);
			 
			 if (file.exists()) {
			     String mimeType = context.getMimeType(file.getPath());

			     if (mimeType == null) {
			         mimeType = "application/octet-stream";
			     }

			     response.setContentType(mimeType);
			     response.addHeader("Content-Disposition", "attachment; filename=\""+NameOfFile+"\"");
			     response.setContentLength((int) file.length());

			     OutputStream os = response.getOutputStream();
			     FileInputStream fis = new FileInputStream(file);
			     byte[] buffer = new byte[4096];
			     int b = -1;

			     while ((b = fis.read(buffer)) != -1) {
			         os.write(buffer, 0, b);
			     }

			     fis.close();
			     os.flush();
			     os.close();
      
			 } else {
			     System.out.println("Requested .xlsx file not found!!");
			 }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		 
		 return "Hr/ViewDetails";
	}
	
}
