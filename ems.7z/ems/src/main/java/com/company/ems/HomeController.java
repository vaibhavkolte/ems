package com.company.ems;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import com.company.ems.model.EmpInfo;
import com.company.ems.model.LoginDetails;
import com.company.ems.model.ToDoList;
import com.company.ems.service.CommonServices;
import com.company.ems.service.HRService;
import com.company.ems.service.LoginService;
import com.company.ems.service.User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController extends SecurityController {

	private static final Logger logger = LoggerFactory
			.getLogger(HomeController.class);

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private CommonServices commonServices;
	
	@Autowired
	private HRService hrService;


	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model,HttpSession session,HttpServletRequest request) {
		
		if(isLoggedIn(session))
		{
			return "redirect:/home";
		}
		
		String userAgent = request.getHeader("User-Agent");
		System.out.println(userAgent);
		
		if(userAgent.contains("rv")|| userAgent.contains("MSIE") )
			return "BrowserNotSupport";
			
		model.addAttribute("login", new LoginDetails());
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Locale locale, Model model,HttpSession session,HttpServletRequest request) {
		if(isLoggedIn(session))
		{
			return "redirect:/home";
		}
		
		String userAgent = request.getHeader("User-Agent");
		System.out.println(userAgent);
		
		if(userAgent.contains("rv")|| userAgent.contains("MSIE") )
			return "BrowserNotSupport";
		
		model.addAttribute("login", new LoginDetails());
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String verifyLogin(
			@ModelAttribute("login") LoginDetails loginDetails, Model model,
			HttpSession session, HttpServletRequest request) {

		try {
			boolean result = loginService.verifyCredential(loginDetails);
			if (result == false) {
				model.addAttribute("msg","Either Username or Password is invalid.");
				return "login";

			} else {

				if (result == true) {
					session.invalidate();
					session = request.getSession();
					session.setAttribute("uname", loginDetails.getUsername());
					String uname = (String) session.getAttribute("uname");
					String role = loginService.getRoleByUserName(uname);
					session.setAttribute("role", role);
					String emsempcode = loginService
							.getEmsEmpByUserName(uname);
					session.setAttribute("emsempcode", emsempcode);
					LoginDetails details = hrService.getEmpDetails((String) session.getAttribute("emsempcode"));
					session.setAttribute("name", details.getName());

					if (role.equalsIgnoreCase("HR")) {
						session.setAttribute("name", details.getName());
						return "redirect:/hrhome";
					} else {
						session.setAttribute("name", details.getName());
						return "redirect:/employeehome";
					}

				} else {
					return "redirect:/login";
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:/login";
		}
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home(Model model, HttpSession session,
			HttpServletResponse response, HttpServletRequest request) {

		if (!isLoggedIn(session)) {
			return "redirect:/";
		}

		String role = (String) session.getAttribute("role");

		if (role.equalsIgnoreCase("HR"))
			return "redirect:/hrhome";
		else if (role.equalsIgnoreCase("EMP"))
			return "redirect:/employeehome";
		else
			return "redirect:/logout";

	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(Model model, HttpSession session,
			HttpServletResponse response, HttpServletRequest request) {

		String name = (String) session.getAttribute("uname");
		System.out.println("inside logout =" + name);

		session.removeAttribute("uname");
		session.removeAttribute("role");
		response.setHeader("Cache-Control",
				"no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		response.setDateHeader("Expires", 0); // Proxies.
		RequestMappingHandlerAdapter rmha = new RequestMappingHandlerAdapter();
		rmha.setCacheSeconds(0);
		session.invalidate();

		return "redirect:/";

	}
	
	@RequestMapping("/todolist")
	public String toDoList(Model model, HttpSession session) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			String  emsempcode = (String) session.getAttribute("emsempcode");
			
			List<ToDoList> taskdtls= commonServices.getAllTaskDetails(emsempcode,"N",0);
			model.addAttribute("new", "yes");
			model.addAttribute("taskdtls", taskdtls);
			model.addAttribute("role", (String) session.getAttribute("role"));
			model.addAttribute("todotask", new ToDoList());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "CommonJsp/ToDoList";

	}

	@RequestMapping(value={"/createTask","/deleteTask"}, method = RequestMethod.POST)
	public String createTask(@ModelAttribute("todotask") @Valid ToDoList todoList,
			BindingResult bindingResult,Model model,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			String req = request.getRequestURI();
			if(req.contains("/createTask"))
			{
			if(bindingResult.hasErrors()){
				List<ToDoList> taskdtls= commonServices.getAllTaskDetails((String) session.getAttribute("emsempcode"),"N",0);
				model.addAttribute("new", "yes");
				model.addAttribute("role", (String) session.getAttribute("role"));
				model.addAttribute("taskdtls", taskdtls);
				model.addAttribute("validate", "error");
				return "CommonJsp/ToDoList";
	        }
			}
			
			if(req.contains("/createTask"))
			{
			todoList.setIsCompleted("N");
			todoList.setEmsempcode((String) session.getAttribute("emsempcode"));
			int result = commonServices.createTask(todoList);
			}else if(req.contains("/deleteTask"))
			{
				todoList = new ToDoList();
				String id = request.getParameter("id");
				List<ToDoList> taskdtls= commonServices.getAllTaskDetails((String) session.getAttribute("emsempcode"),"N",Integer.parseInt(id));
				todoList = taskdtls.get(0);
				todoList.setIsCompleted("Y");
				int result = commonServices.createTask(todoList);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/todolist";

	}
	
	@RequestMapping("/*")
	public String defaultMthod(Model model,HttpSession session) {

		try {
			model.addAttribute("role", (String) session.getAttribute("role"));
			model.addAttribute("errorcode", "404");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "ErrorPage";

	}

	@RequestMapping("/AccessDenied")
	public String accessDenied(Model model, HttpSession session) {
		if (null == session.getAttribute("uname")) {
			return "redirect:/";
		}

		model.addAttribute("errorcode", "403");
		return "ErrorPage";

	}
}
