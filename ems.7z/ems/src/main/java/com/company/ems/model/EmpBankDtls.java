package com.company.ems.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="EmpBankDtls")
public class EmpBankDtls {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	@Column(name="emsempcode")
	private String emsempcode;
	@Valid 
	@NotBlank(message="Name mandatory")
	@Column(name="nameasperbnk")
	private String nameasperbnk;
	@Valid 
	@NotBlank(message="Account Number mandatory")
	@Column(name="bankaccno")
	private String bankaccno;
	@Valid 
	@NotBlank(message="Bank Name mandatory")
	@Column(name="bankname")
	private String bankname;
	@Valid 
	@NotBlank(message="Branch Name mandatory")
	@Column(name="branchname")
	private String branchname;
	@Valid 
	@NotBlank(message="IFSC code mandatory")
	@Column(name="ifsccode")
	private String ifsccode;
	@Valid 
	@NotBlank(message="Pan mandatory")
	@Column(name="pannumber")
	private String pannumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public String getNameasperbnk() {
		return nameasperbnk;
	}
	public void setNameasperbnk(String nameasperbnk) {
		this.nameasperbnk = nameasperbnk;
	}
	public String getBankaccno() {
		return bankaccno;
	}
	public void setBankaccno(String bankaccno) {
		this.bankaccno = bankaccno;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	public String getPannumber() {
		return pannumber;
	}
	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}
	
	@Override
	public String toString() {
		return "EmpBankDtls [id=" + id + ", emsempcode=" + emsempcode
				+ ", nameasperbnk=" + nameasperbnk + ", bankaccno=" + bankaccno
				+ ", bankname=" + bankname + ", branchname=" + branchname
				+ ", ifsccode=" + ifsccode + ", pannumber=" + pannumber + "]";
	}


}
