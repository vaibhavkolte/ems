package com.company.ems.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.company.ems.model.EmpInfo;
import com.company.ems.model.LoginDetails;

@Transactional
@Repository("HRServiceDao")
public class HRServiceDaoImpl implements HRServiceDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int doRegistration(LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(loginDetails);
		return loginDetails.getId();
	}

	@Override
	public List<EmpInfo> getAllEmployeeDetails(String type) {
		// TODO Auto-generated method stub
		
		@SuppressWarnings("unchecked")
		List<EmpInfo> empinfo = sessionFactory.getCurrentSession()
		.createCriteria(EmpInfo.class)
		.add(Restrictions.eq("isactive",type))
		.list();
		return empinfo;
	}

	@Override
	public List<LoginDetails> getActiveEmplyee() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<LoginDetails> activelist = sessionFactory.getCurrentSession().
					createCriteria(LoginDetails.class)
					.add(Restrictions.eq("isactive", "Y"))
					.add(Restrictions.ne("role", "HR"))
					.list();
		return activelist;
	}

	@Override
	public List<LoginDetails> getInactiveEmplyee() {
		@SuppressWarnings("unchecked")
		List<LoginDetails> inactivelist = sessionFactory.getCurrentSession().
					createCriteria(LoginDetails.class)
					.add(Restrictions.eq("isactive", "N"))
					.add(Restrictions.ne("role", "HR"))
					.list();
		return inactivelist;
	}

	@Override
	public int deactivateEmployee(LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(loginDetails);
		return loginDetails.getId();
	}

	@Override
	public LoginDetails getEmpDetails(String emsempcode) {
		// TODO Auto-generated method stub
		if(emsempcode.contains("EMS"))
		{
		@SuppressWarnings("unchecked")
		List<LoginDetails> activelist = sessionFactory.getCurrentSession().
					createCriteria(LoginDetails.class)
					.add(Restrictions.eq("emsempcode", emsempcode))
					.list();
		return activelist.get(0);
		}
	else{
			@SuppressWarnings("unchecked")
			List<LoginDetails> activelist = sessionFactory.getCurrentSession().
					createCriteria(LoginDetails.class)
					.add(Restrictions.eq("username", emsempcode))
					.list();
		if(activelist.size()>0)
			return activelist.get(0);
		else
			return null;
		}
		
	}

	@Override
	public List<EmpInfo> getBirthDayDetails(Date fromdate, Date todate) {
		List<EmpInfo> empinfo = new ArrayList<EmpInfo>();
		try {
			String hql = "SELECT firstname as firstname, middlename as middlename,lastname as lastname,"
					+ " DATE_FORMAT(dob, "+"'%d %M'"+") as strdob FROM EmpInfo where day(dob)"
					+ " between day(current_date()) and  LAST_DAY(current_date()) "
					+ "and month(dob) = month(current_date())";
			Query qry =  sessionFactory.getCurrentSession().createQuery(hql);
			qry.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			empinfo = qry.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		
		return empinfo;
	}

	@Override
	public List<LoginDetails> getAllEmpLoginDetails() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<LoginDetails> activelist = sessionFactory.getCurrentSession().
					createCriteria(LoginDetails.class)
					.list();
		return activelist;
	}
	
	

}
