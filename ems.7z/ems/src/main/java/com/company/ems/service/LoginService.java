package com.company.ems.service;

import com.company.ems.model.LoginDetails;

public interface LoginService {

	public boolean verifyCredential(LoginDetails loginDetails);

	public String getRoleByUserName(String uname);

	public String getEmsEmpByUserName(String uname);

}
