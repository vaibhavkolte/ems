package com.company.ems;

import javax.servlet.http.HttpSession;

public class SecurityController {
	
	public Boolean isLoggedIn(HttpSession session){
		
		return session.getAttribute("uname")!=null;
	}
	
	public Boolean checkRole(HttpSession session,String role){
		
		String sessionrole = (String) session.getAttribute("role");
		
		return sessionrole.equalsIgnoreCase(role);
	}

}


