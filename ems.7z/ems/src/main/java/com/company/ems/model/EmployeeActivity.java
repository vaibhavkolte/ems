package com.company.ems.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EmployeeActivity")
public class EmployeeActivity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	@Column(name="emsempcode")
	private String emsempcode;
	@Column(name="stepone")
	private String stepone;
	@Column(name="isEditable1")
	private String isEditable1;
	@Column(name="steptwo")
	private String steptwo;
	@Column(name="isEditable2")
	private String isEditable2;
	@Column(name="stepthree")
	private String stepthree;
	@Column(name="isEditable3")
	private String isEditable3;
	@Column(name="stepfour")
	private String stepfour;
	@Column(name="isEditable4")
	private String isEditable4;
	@Column(name="stepfive")
	private String stepfive;
	@Column(name="isEditable5")
	private String isEditable5;
	@Column(name="stepsix")
	private String stepsix;
	@Column(name="isEditable6")
	private String isEditable6;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public String getStepone() {
		return stepone;
	}
	public void setStepone(String stepone) {
		this.stepone = stepone;
	}
	public String getIsEditable1() {
		return isEditable1;
	}
	public void setIsEditable1(String isEditable1) {
		this.isEditable1 = isEditable1;
	}
	public String getSteptwo() {
		return steptwo;
	}
	public void setSteptwo(String steptwo) {
		this.steptwo = steptwo;
	}
	public String getIsEditable2() {
		return isEditable2;
	}
	public void setIsEditable2(String isEditable2) {
		this.isEditable2 = isEditable2;
	}
	public String getStepthree() {
		return stepthree;
	}
	public void setStepthree(String stepthree) {
		this.stepthree = stepthree;
	}
	public String getIsEditable3() {
		return isEditable3;
	}
	public void setIsEditable3(String isEditable3) {
		this.isEditable3 = isEditable3;
	}
	public String getStepfour() {
		return stepfour;
	}
	public void setStepfour(String stepfour) {
		this.stepfour = stepfour;
	}
	public String getIsEditable4() {
		return isEditable4;
	}
	public void setIsEditable4(String isEditable4) {
		this.isEditable4 = isEditable4;
	}
	public String getStepfive() {
		return stepfive;
	}
	public void setStepfive(String stepfive) {
		this.stepfive = stepfive;
	}
	public String getIsEditable5() {
		return isEditable5;
	}
	public void setIsEditable5(String isEditable5) {
		this.isEditable5 = isEditable5;
	}
	public String getStepsix() {
		return stepsix;
	}
	public void setStepsix(String stepsix) {
		this.stepsix = stepsix;
	}
	public String getIsEditable6() {
		return isEditable6;
	}
	public void setIsEditable6(String isEditable6) {
		this.isEditable6 = isEditable6;
	}
	
}
