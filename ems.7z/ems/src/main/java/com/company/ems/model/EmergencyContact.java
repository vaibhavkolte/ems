package com.company.ems.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="EmergencyContact")
public class EmergencyContact {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	@Valid 
	@NotBlank(message="Name mandatory")
	@Column(name="name")
	private String name;
	@Valid 
	@NotBlank(message="Address mandatory")
	@Column(name="address")
	private String address;
	@Valid 
	@NotBlank(message="City mandatory")
	@Column(name="city")
	private String city;
	@Valid 
	@NotBlank(message="State mandatory")
	@Column(name="state")
	private String state;
	@Valid 
	@NotBlank(message="Pincode mandatory")
	@Column(name="pincode")
	private String pincode;
	@Valid 
	@NotBlank(message="Mobile mandatory")
	@Column(name="mobilenumber")
	private String mobilenumber;
	@Valid 
	@NotBlank(message="Relationship mandatory")
	@Column(name="relationship")
	private String relationship;
	@Column(name="emsempcode")
	private String emsempcode;	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode; 
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	
	@Override
	public String toString() {
		return "EmergencyContact [id=" + id + ", name=" + name + ", address="
				+ address + ", city=" + city + ", state=" + state
				+ ", pincode=" + pincode + ", mobilenumber=" + mobilenumber
				+ ", relationship=" + relationship + ", emsempcode="
				+ emsempcode + "]";
	}
}
