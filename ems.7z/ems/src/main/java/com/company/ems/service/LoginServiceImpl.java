package com.company.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.ems.dao.LoginDao;
import com.company.ems.model.LoginDetails;

@Service("LoginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao;

	@Override
	public boolean verifyCredential(LoginDetails loginDetails) {
		boolean isUserVerified = false;
		// String userName =
		// loginDao.findUserByUserName(loginDetails.getUsername());
		// String password =
		// loginDao.findPassByUserName(loginDetails.getUsername());
		LoginDetails loginDetailslist = new LoginDetails();
		loginDetailslist = loginDao.getUserDetailsByUsername(loginDetails
				.getUsername());

		if (loginDetailslist == null)
			return isUserVerified;

		// int roleId=loginDAO.RoleId(appUser.getUserName());
		String userName = loginDetailslist.getUsername();
		String password = loginDetailslist.getPassword();
		String isactive = loginDetailslist.getIsactive();
		System.out.println("userName is " + userName);
		System.out.println("password is " + password);
		if (userName == null || password == null || userName.isEmpty()
				|| password.isEmpty() || isactive.isEmpty()
				|| isactive.isEmpty()) {
			return isUserVerified;
		} else {
			if (userName.equalsIgnoreCase(loginDetails.getUsername())
					&& !userName.equals("") && !password.equals("")
					&& password.equals(loginDetails.getPassword())
					&& !isactive.equals("") && isactive.equalsIgnoreCase("Y")) {
				return isUserVerified = true;
			} else {
				return isUserVerified;
			}

		}

	}

	@Override
	public String getRoleByUserName(String uname) {
		// TODO Auto-generated method stub
		return loginDao.getRoleByUserName(uname);
	}

	@Override
	public String getEmsEmpByUserName(String uname) {
		// TODO Auto-generated method stub
		return loginDao.getEmsEmpByUserName(uname);
	}

}
