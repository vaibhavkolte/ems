package com.company.ems.dao;

import java.util.List;

import com.company.ems.model.ToDoList;

public interface CommonDao {

	public int createTask(ToDoList todoList);

	public List<ToDoList> getAllTaskDetails(String emsempcode,
			String isCompleted, int id);

}
