package com.company.ems.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.validation.annotation.Validated;

@Entity
@Table(name="EmpInfo")
public class EmpInfo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	@Valid 
	@NotBlank(message="Employee Code mandatory")
	@Column(name="employeecode")
	private String employeecode;
	@Column(name="emsempcode")
	private String emsempcode;
	/*@Valid 
	@NotBlank(message="Please select Date of Joining")*/
	@Column(name="doj")
	private Date   doj;
	@Valid 
	@NotBlank(message="Job Location mandatory")
	@Column(name="joblocation")
	private String joblocation;
	@Valid 
	@NotBlank(message="First Name mandatory")
	@Column(name="firstname")
	private String firstname;
	@Valid 
	@NotBlank(message="Middle Name mandatory")
	@Column(name="middlename")
	private String middlename;
	@Valid 
	@NotBlank(message="Last Name mandatory")
	@Column(name="lastname")
	private String lastname;
	/*@Valid 
	@NotBlank(message="Please select Date Of Birh")*/
	@Column(name="dob")
	private Date   dob;
	@Valid 
	@NotBlank(message="Please select  Marital Status")
	@Column(name="maritalsts")
	private String maritalsts;
	@Valid 
	@NotBlank(message="Please select Gender")
	@Column(name="gender")
	private String gender;
	@Valid 
	@NotBlank(message="Blood Group mandatory")
	@Column(name="bloodgroup")
	private String bloodgroup;
	@Valid 
	@NotBlank(message="Please select Physical Disability")
	@Column(name="physicaldibability")
	private String physicaldibability;
	@Valid 
	@NotBlank(message="Nationality mandatory")
	@Column(name="nationality")
	private String nationality;
	@Valid 
	@NotBlank(message="Email mandatory")
	@Email(message ="Please enter valid Email") 
	@Column(name="emailid")
	private String emailid;
	@Valid 
	@NotBlank(message="Phone mandatory")
	@Column(name="phone")
	private String phone;
	@Valid 
	@NotBlank(message="Mobile mandatory")
	@Column(name="mobile")
	private String mobile;
	@Valid 
	@NotBlank(message="Residential Address mandatory")
	@Column(name="paddress")
	private String paddress;
	@Valid 
	@NotBlank(message="City mandatory")
	@Column(name="pcity")
	private String pcity;
	@Valid 
	@NotBlank(message="State mandatory")
	@Column(name="pstate")
	private String pstate;
	@Valid 
	@NotBlank(message="Zip Code mandatory")
	@Column(name="pzipcode")
	private String pzipcode;
	@Valid 
	@NotBlank(message="Communication / Mailing Address mandatory")
	@Column(name="caddress")
	private String caddress;
	@Valid 
	@NotBlank(message="City mandatory")
	@Column(name="ccity")
	private String ccity;
	@Valid 
	@NotBlank(message="State mandatory")
	@Column(name="cstate")
	private String cstate;
	@Valid 
	@NotBlank(message="Zip Code mandatory")
	@Column(name="czipcode")
	private String czipcode;
	@Column(name="photopath")
	private String photopath;
	@Valid 
	@NotBlank(message="Designation mandatory")
	@Column(name="cur_designation")
	private String designation;
	@Column(name="isActive")
	private String isactive;
	
	@Transient
	private String   strdob;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmployeecode() {
		return employeecode;
	}
	public void setEmployeecode(String employeecode) {
		this.employeecode = employeecode;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getJoblocation() {
		return joblocation;
	}
	public void setJoblocation(String joblocation) {
		this.joblocation = joblocation;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddlename() {
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getMaritalsts() {
		return maritalsts;
	}
	public void setMaritalsts(String maritalsts) {
		this.maritalsts = maritalsts;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getPhysicaldibability() {
		return physicaldibability;
	}
	public void setPhysicaldibability(String physicaldibability) {
		this.physicaldibability = physicaldibability;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPaddress() {
		return paddress;
	}
	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}
	public String getPcity() {
		return pcity;
	}
	public void setPcity(String pcity) {
		this.pcity = pcity;
	}
	public String getPstate() {
		return pstate;
	}
	public void setPstate(String pstate) {
		this.pstate = pstate;
	}
	public String getPzipcode() {
		return pzipcode;
	}
	public void setPzipcode(String pzipcode) {
		this.pzipcode = pzipcode;
	}
	public String getCaddress() {
		return caddress;
	}
	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	public String getCcity() {
		return ccity;
	}
	public void setCcity(String ccity) {
		this.ccity = ccity;
	}
	public String getCstate() {
		return cstate;
	}
	public void setCstate(String cstate) {
		this.cstate = cstate;
	}
	public String getCzipcode() {
		return czipcode;
	}
	public void setCzipcode(String czipcode) {
		this.czipcode = czipcode;
	}
	public String getPhotopath() {
		return photopath;
	}
	public void setPhotopath(String photopath) {
		this.photopath = photopath;
	}
	@Override
	public String toString() {
		return "EmpInfo [id=" + id + ", employeecode=" + employeecode
				+ ", emsempcode=" + emsempcode + ", doj=" + doj
				+ ", joblocation=" + joblocation + ", firstname=" + firstname
				+ ", middlename=" + middlename + ", lastname=" + lastname
				+ ", dob=" + dob + ", maritalsts=" + maritalsts + ", gender="
				+ gender + ", bloodgroup=" + bloodgroup
				+ ", physicaldibability=" + physicaldibability
				+ ", nationality=" + nationality + ", emailid=" + emailid
				+ ", phone=" + phone + ", mobile=" + mobile + ", paddress="
				+ paddress + ", pcity=" + pcity + ", pstate=" + pstate
				+ ", pzipcode=" + pzipcode + ", caddress=" + caddress
				+ ", ccity=" + ccity + ", cstate=" + cstate + ", czipcode="
				+ czipcode + ", photopath=" + photopath + "]";
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getIsactive() {
		return isactive;
	}
	public void setIsactive(String isactive) {
		this.isactive = isactive;
	}
	public String getStrdob() {
		return strdob;
	}
	public void setStrdob(String strdob) {
		this.strdob = strdob;
	}
		
	
}
