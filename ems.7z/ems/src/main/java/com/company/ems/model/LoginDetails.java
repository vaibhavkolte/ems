package com.company.ems.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Check;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Usermaster")
public class LoginDetails {
	
	private static final String message = null;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Valid 
	@NotEmpty(message="Name may not be empty")
	@Column(name="name")
	private String name;
	@Valid 
	@Email(message ="Please enter valid Email") 
	@NotEmpty(message="Username may not be empty")
	@Column(name="username")
	private String username;
	@Valid 
	@NotEmpty(message="Password may not be empty")
	@Column(name="password")
	private String password;
	@Valid 
	@NotEmpty(message="Please select role")
	@Column(name="role")
	private String role;
	@Column(name="emsempcode")
	private String emsempcode;
	@Column(name="isactive")
	private String isactive;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmsempcode() {
		return emsempcode;
	}
	public void setEmsempcode(String emsempcode) {
		this.emsempcode = emsempcode;
	}
	public String getIsactive() {
		return isactive;
	}
	public void setIsactive(String isactive) {
		this.isactive = isactive;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
