package com.company.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.ems.dao.EmployeeDao;
import com.company.ems.model.EducationalDetails;
import com.company.ems.model.EmergencyContact;
import com.company.ems.model.EmpBankDtls;
import com.company.ems.model.EmpInfo;
import com.company.ems.model.FamilyInformation;
import com.company.ems.model.WorkExperience;

@Service("EmployeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;
	
	@Override
	public String saveEmpData(EmpInfo empinfo) {

		employeeDao.saveEmpData(empinfo);
		return "Data Inserted";
	}

	@Override
	public int saveEmpBankData(EmpBankDtls empbankdtls) {
		return employeeDao.saveEmpBankData(empbankdtls);
	}

	@Override
	public int saveEmergencyContactData(EmergencyContact emergencycontact) {
		return employeeDao.saveEmergencyContactData(emergencycontact);
	}

	@Override
	public int saveEducationalDetailsData(
			EducationalDetails educationaldetails) {
		return employeeDao.saveEducationalDetailsData(educationaldetails);
	}

	@Override
	public int saveFamilyInformationData(FamilyInformation familyinformation) {
		// TODO Auto-generated method stub
		return employeeDao.saveFamilyInformationData(familyinformation);
	}

	@Override
	public int saveWorkExperienceData(WorkExperience workexp) {
		// TODO Auto-generated method stub
		return employeeDao.saveWorkExperienceData(workexp);
	}

	@Override
	public List<EmpInfo> getEmployeeDetailsByEMSEmpCode(String uname) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeDetailsByEMSEmpCode(uname);
	}

	@Override
	public List<EducationalDetails> getEducationalDetailsByEMSID(String emsid) {
		// TODO Auto-generated method stub
		return employeeDao.getEducationalDetailsByEMSID(emsid);
	}

	@Override
	public List<WorkExperience> getworkExperienceByEMSID(String emsid) {
		// TODO Auto-generated method stub
		return employeeDao.getworkExperienceByEMSID(emsid);
	}

	@Override
	public List<EmpBankDtls> getBankDetailsByEMSID(String emsid) {
		// TODO Auto-generated method stub
		return employeeDao.getBankDetailsByEMSID(emsid);
	}

	@Override
	public List<EmergencyContact> getEmergencyContactDetailsByEMSID(String emsid) {
		// TODO Auto-generated method stub
		return employeeDao.getEmergencyContactDetailsByEMSID(emsid);
	}

	@Override
	public List<FamilyInformation> getFamilyInformationByEMSID(String emsempcode) {
		// TODO Auto-generated method stub
		return employeeDao.getFamilyInformationByEMSID(emsempcode);
	}

	@Override
	public EducationalDetails getSingleEducationalDetailsByEMSID(
			String emsempcode, String id) {
		// TODO Auto-generated method stub
		return employeeDao.getSingleEducationalDetailsByEMSID(emsempcode,id);
	}

	@Override
	public WorkExperience getSingeWorkExperienceByEMSID(String emsempcode,
			String id) {
		// TODO Auto-generated method stub
		return employeeDao.getSingeWorkExperienceByEMSID(emsempcode,id);
	}


}
