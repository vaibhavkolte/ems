package com.company.ems.service;

import java.util.List;

import com.company.ems.model.ToDoList;

public interface CommonServices {

	public int createTask(ToDoList todoList);

	public List<ToDoList> getAllTaskDetails(String emsempcode, String isCompleted, int id);

}
