package com.company.ems.dao;

import java.util.List;

import com.company.ems.model.LoginDetails;

public interface LoginDao {

public String findUserByUserName(String username);

public String findPassByUserName(String username);

public String getRoleByUserName(String uname);

public String getEmsEmpByUserName(String uname);

public LoginDetails getUserDetailsByUsername(String username);

}
