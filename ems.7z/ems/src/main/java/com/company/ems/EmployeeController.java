package com.company.ems;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.company.ems.model.EducationalDetails;
import com.company.ems.model.EmergencyContact;
import com.company.ems.model.EmpBankDtls;
import com.company.ems.model.EmpInfo;
import com.company.ems.model.FamilyInformation;
import com.company.ems.model.LoginDetails;
import com.company.ems.model.WorkExperience;
import com.company.ems.service.EmployeeService;

@Controller
@PropertySource("classpath:application.properties")
public class EmployeeController extends SecurityController{

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private Environment env;

	private static final Logger logger = LoggerFactory
			.getLogger(EmployeeController.class);

	@RequestMapping(value = "/employeehome", method = RequestMethod.GET)
	public String home(Locale locale, Model model, HttpSession session,
			HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";
			
			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<EmpInfo> empinfo = employeeService
					.getEmployeeDetailsByEMSEmpCode(emsempcode);
			if (empinfo.size() == 1)
				enable = true;

			model.addAttribute("empinfolist", empinfo);
			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("empinfo", new EmpInfo());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Employee/employeehome";
	}

	@RequestMapping(value = "/saveEmpData", method = RequestMethod.POST)
	public String saveEmpData(@RequestParam("file") MultipartFile file,
			@ModelAttribute("empinfo") @Valid EmpInfo empinfo,BindingResult bindingResult, Model model,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";
			
			if(bindingResult.hasErrors()){
				model.addAttribute("enable", false);
				model.addAttribute("new", "yes");
				return "Employee/employeehome";
	        }

			String emsempcode = (String) session.getAttribute("emsempcode");
			String name = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
				   name	= emsempcode+name;
			String filepath = env.getRequiredProperty("employeedocpath");
			filepath = filepath + emsempcode;

			empinfo.setPhotopath(name);
			empinfo.setEmsempcode(emsempcode);
			empinfo.setIsactive("A");;
			logger.info("In saveEmpData", empinfo);
			
			uploadFile(filepath,name,file);
			employeeService.saveEmpData(empinfo);
		} catch (Exception e) {
			logger.info("In Catch", e);
			e.printStackTrace();
		}

		return "redirect:/employeehome";

	}

	@RequestMapping(value = "/empbankdtls", method = RequestMethod.GET)
	public String empBankDtls(Locale locale, Model model, HttpSession session,
			HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";

			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<EmpBankDtls> bankinfo = employeeService
					.getBankDetailsByEMSID(emsempcode);
			model.addAttribute("bankinfo", bankinfo);

			if (bankinfo.size() > 0)
				enable = true;

			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("empbankdtls", new EmpBankDtls());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Employee/EmpBankDtls";
	}

	@RequestMapping(value = "/saveEmpBankData", method = RequestMethod.POST)
	public String saveEmpBankData(
			@ModelAttribute("empbankdtls") @Valid EmpBankDtls empbankdtls,BindingResult bindingResult,
			Model model, HttpSession session, HttpServletRequest request) {

		if (!isLoggedIn(session)) {
			return "redirect:/";
		}
		
		if (!session.getAttribute("role").equals("EMP"))
			return "redirect:/AccessDenied";
		
		if(bindingResult.hasErrors()){
			model.addAttribute("enable", false);
			model.addAttribute("new", "yes");
			return "Employee/EmpBankDtls";
        }

		try {
			String emsempcode = (String) session.getAttribute("emsempcode");
			empbankdtls.setEmsempcode(emsempcode);
			int rowcnt = employeeService.saveEmpBankData(empbankdtls);
			if (rowcnt > 0)
				logger.info("Row Count : ", rowcnt);
		} catch (Exception e) {
			logger.info("In Catch", e);
			e.printStackTrace();
		}

		return "redirect:/empbankdtls";

	}

	@RequestMapping(value = "/emergencycontact", method = RequestMethod.GET)
	public String emergencyContact(Locale locale, Model model,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";
			
			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<EmergencyContact> emergencycnt = employeeService
					.getEmergencyContactDetailsByEMSID(emsempcode);
			model.addAttribute("emergencycnt", emergencycnt);

			if (emergencycnt.size() > 0)
				enable = true;

			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("emergencycontact", new EmergencyContact());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Employee/EmergencyContact";
	}

	@RequestMapping(value = "/saveEmergencyContactData", method = RequestMethod.POST)
	public String saveEmergencyContactData(
			@ModelAttribute("emergencycontact") @Valid EmergencyContact emergencycontact,BindingResult bindingResult,
			Model model, HttpSession session, HttpServletRequest request) {
		if (!isLoggedIn(session)) {
			return "redirect:/";
		}
		
		if (!session.getAttribute("role").equals("EMP"))
			return "redirect:/AccessDenied";
		
		if(bindingResult.hasErrors()){
			model.addAttribute("enable", false);
			model.addAttribute("new", "yes");
			return "Employee/EmergencyContact";
        }
		
		try {
			String emsempcode = (String) session.getAttribute("emsempcode");
			emergencycontact.setEmsempcode(emsempcode);
			int rowcnt = employeeService
					.saveEmergencyContactData(emergencycontact);
			if (rowcnt > 0)
				logger.info("Row Count : ", rowcnt);
		} catch (Exception e) {
			logger.info("In Catch", e);
			e.printStackTrace();
		}

		return "redirect:/emergencycontact";

	}

	@RequestMapping(value = "/family-information", method = RequestMethod.GET)
	public String familyInformation(Locale locale, Model model,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";

			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<FamilyInformation> familyinfo = employeeService
					.getFamilyInformationByEMSID(emsempcode);
			model.addAttribute("familyinfo", familyinfo);

			if (familyinfo.size() > 0)
				enable = true;

			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("familyinformation", new FamilyInformation());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Employee/FamilyInformation";
	}

	@RequestMapping(value = "/saveFamilyInformationData", method = RequestMethod.POST)
	public String saveFamilyInformationData(
			@ModelAttribute("familyinformation") @Valid FamilyInformation familyinformation,BindingResult bindingResult,
			Model model, HttpSession session, HttpServletRequest request) {
		if (!isLoggedIn(session)) {
			return "redirect:/";
		}
		
		if (!session.getAttribute("role").equals("EMP"))
			return "redirect:/AccessDenied";
		
		if(bindingResult.hasErrors()){
			model.addAttribute("enable", false);
			model.addAttribute("new", "yes");
			return "Employee/FamilyInformation";
        }
		
		try {
			String emsempcode = (String) session.getAttribute("emsempcode");
			familyinformation.setEmsempcode(emsempcode);
			int rowcnt = employeeService
					.saveFamilyInformationData(familyinformation);
			if (rowcnt > 0)
				logger.info("Row Count : ", rowcnt);
		} catch (Exception e) {
			logger.info("In Catch", e);
			e.printStackTrace();
		}

		return "redirect:/family-information";

	}

	@RequestMapping(value = "/educational-qualification", method = RequestMethod.GET)
	public String educationalDetails(Locale locale, Model model,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";
			
			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<EducationalDetails> educationaldetailslist = employeeService
					.getEducationalDetailsByEMSID(emsempcode);
			model.addAttribute("educationaldetailslist", educationaldetailslist);

			if (educationaldetailslist.size() > 0)
				enable = true;

			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("educationaldetails", new EducationalDetails());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Employee/EducationalDetails";
	}

	@RequestMapping(value = "/saveEducationalDetailsData", method = RequestMethod.POST)
	public String saveEducationalDetailsData(@RequestParam("file") MultipartFile file,
			@ModelAttribute("educationaldetails") @Valid EducationalDetails educationaldetails,BindingResult bindingResult,
			Model model, HttpSession session, HttpServletRequest request) {
		if (!isLoggedIn(session)) {
			return "redirect:/";
		}
		try {
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";
			
			if(bindingResult.hasErrors()){
				boolean enable = false;
				String emsempcode = (String) session.getAttribute("emsempcode");
				List<EducationalDetails> educationaldetailslist = employeeService
						.getEducationalDetailsByEMSID(emsempcode);
				if(educationaldetailslist.size() > 0)
					enable = true;
				
				model.addAttribute("educationaldetailslist", educationaldetailslist);
				model.addAttribute("enable", enable);
				model.addAttribute("new", "yes");
				model.addAttribute("validate", "error");
				return "Employee/EducationalDetails";
	        }
			String emsempcode = (String) session.getAttribute("emsempcode");
			String name = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
				   name	= educationaldetails.getEducationallevel()+"Cert"+name;
			String filepath = env.getRequiredProperty("employeedocpath");
			filepath = filepath + emsempcode;
			
			educationaldetails.setFilepath(name);
			educationaldetails.setEmsempcode(emsempcode);
			uploadFile(filepath,name,file);
			int rowcnt = employeeService
					.saveEducationalDetailsData(educationaldetails);
			if (rowcnt > 0)
				logger.info("Row Count : ", rowcnt);
		} catch (Exception e) {
			logger.info("In Catch", e);
			e.printStackTrace();
		}

		return "redirect:/educational-qualification";

	}

	@RequestMapping(value = "/Work-Experience", method = RequestMethod.GET)
	public String workExperience(Locale locale, Model model,
			HttpSession session, HttpServletRequest request) {
		try {
			if (!isLoggedIn(session)) {
				return "redirect:/";
			}
			
			if (!session.getAttribute("role").equals("EMP"))
				return "redirect:/AccessDenied";
			
			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<WorkExperience> workexplist = employeeService
					.getworkExperienceByEMSID(emsempcode);
			model.addAttribute("workexplist", workexplist);

			if (workexplist.size() > 0)
				enable = true;

			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("workexp", new WorkExperience());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Employee/WorkExperience";
	}

	@RequestMapping(value = "/saveWorkExperienceData", method = RequestMethod.POST)
	public String saveWorkExperienceData(@RequestParam("file") MultipartFile file,
			@ModelAttribute("workexp") @Valid WorkExperience workexp,
			BindingResult bindingResult,Model model,
			HttpSession session, HttpServletRequest request) {
		if (!isLoggedIn(session)) {
			return "redirect:/";
		}
		
		if (!session.getAttribute("role").equals("EMP"))
			return "redirect:/AccessDenied";
		
		if(bindingResult.hasErrors()){
			boolean enable = false;
			String emsempcode = (String) session.getAttribute("emsempcode");
			List<WorkExperience> workexplist = employeeService
					.getworkExperienceByEMSID(emsempcode);
			model.addAttribute("workexplist", workexplist);

			if (workexplist.size() > 0)
				enable = true;
			model.addAttribute("enable", enable);
			model.addAttribute("new", "yes");
			model.addAttribute("validate", "error");
			return "Employee/WorkExperience";
        }
		
		try {
			String emsempcode = (String) session.getAttribute("emsempcode");
			String name = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
				   name	= workexp.getOrg_name()+"ExpLetter"+name;
			String filepath = env.getRequiredProperty("employeedocpath");
			filepath = filepath + emsempcode;
			
			workexp.setFilepath(name);
			workexp.setEmsempcode(emsempcode);
			uploadFile(filepath,name,file);
			int rowcnt = employeeService.saveWorkExperienceData(workexp);
			if (rowcnt > 0)
				logger.info("Row Count : ", rowcnt);
		} catch (Exception e) {
			logger.info("In Catch", e);
			e.printStackTrace();
		}

		return "redirect:/Work-Experience";

	}
	
	private String uploadFile(String filepath,String name,MultipartFile file)
	{
		String response ="Failed";
		try {
			if (!file.isEmpty()) {
				try {
					byte[] bytes = file.getBytes();

					File dir = new File(filepath);
					if (!dir.exists())
						dir.mkdirs();

					File serverFile = new File(dir.getAbsolutePath()
							+ File.separator + name);

					System.out.println("file address = " + serverFile);
					BufferedOutputStream stream = new BufferedOutputStream(
							new FileOutputStream(serverFile));
					stream.write(bytes);
					stream.close();

					System.out.println("Server File Location="
							+ serverFile.getAbsolutePath());

					System.out.println("You successfully uploaded file=" + name);
					 response ="Success";
				} catch (Exception e) {
					 response ="Failed";
					System.out.println("You failed to upload " + name + " => "
							+ e.getMessage());
				}
			} else {
				 response ="Failed";
				System.out.println("You failed to upload " + name
						+ " because the file was empty.");
			}
		} catch (Exception e) {
			 response ="Failed";
			e.printStackTrace();
		}
		return response;
	}
}
