package com.company.ems.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.company.ems.model.EmpInfo;
import com.company.ems.model.ToDoList;

@Transactional
@Repository("CommonDao")
public class CommonDaoImpl implements CommonDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int createTask(ToDoList todoList) {

		sessionFactory.getCurrentSession().saveOrUpdate(todoList);
		return todoList.getId();
	}

	@Override
	public List<ToDoList> getAllTaskDetails(String emsempcode,
			String isCompleted,int id) {
		List<ToDoList> taskdetails = new ArrayList<ToDoList>();
		if(id==0)
		{
		@SuppressWarnings("unchecked")
		List<ToDoList> taskdetails1 = sessionFactory.getCurrentSession().createCriteria(ToDoList.class)
		.add(Restrictions.eq("emsempcode", emsempcode))
		.add(Restrictions.eq("isCompleted", isCompleted))
		.list();
		return taskdetails1;
		}
		else if(id>0)
		{
			@SuppressWarnings("unchecked")
			List<ToDoList> taskdetails2 = sessionFactory.getCurrentSession().createCriteria(ToDoList.class)
			.add(Restrictions.eq("emsempcode", emsempcode))
			.add(Restrictions.eq("id", id))
			.list();
			return taskdetails2;
		}
		
		return taskdetails;
	}

}
